figma.showUI(__html__, { width: 360, height: 480 });

figma.ui.onmessage = async msg => {
  if (msg.type === 'analyze-image') {
    const selection = figma.currentPage.selection;
    if (selection.length !== 1 || selection[0].type !== 'RECTANGLE' || !selection[0].fills) {
      figma.ui.postMessage({ error: 'Please select one rectangle image.' });
      return;
    }

    const fill = selection[0].fills[0];
    if (fill.type !== 'IMAGE') {
      figma.ui.postMessage({ error: 'Selected rectangle must contain an image fill.' });
      return;
    }

    const imageHash = fill.imageHash;
    const image = figma.getImageByHash(imageHash);
    const bytes = await image.getBytesAsync();

    const { width, height } = selection[0];
    figma.ui.postMessage({ imageBytes: bytes, width: Math.round(width), height: Math.round(height) });
  }
};